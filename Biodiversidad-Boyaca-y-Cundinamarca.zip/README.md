# Biodiversidad-Boyaca-y-Cundinamarca
Desarrollar una aplicación web interactiva que permita a los usuarios explorar 
y aprender sobre la biodiversidad en Cundinamarca y Boyacá, utilizando 
conceptos aprendidos en HTML, CSS, JavaScript, Python, Pandas y NumPy.
